// BARBELL BIOTECH — MAILING LIST GOOGLE APPS SCRIPT
// 1. Create a new Google Sheet — copy its ID into SHEET_ID below
// 2. Deploy as Web App: Execute as Me, Who has access: Anyone
// 3. Copy the deployed URL into config.js as MAILING_SCRIPT_URL

const MAILING_SHEET_ID = 'YOUR_SHEET_ID_HERE'; // ← paste your sheet ID

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);

    if (data.action === 'subscribe') {
      const email = (data.email || '').trim().toLowerCase();

      // Basic validation
      if (!email || !email.includes('@')) {
        return response({ success: false, error: 'Invalid email' });
      }

      const ss = SpreadsheetApp.openById(MAILING_SHEET_ID);
      let sheet = ss.getSheetByName('Subscribers');

      // Create sheet with headers if it doesn't exist
      if (!sheet) {
        sheet = ss.insertSheet('Subscribers');
        sheet.getRange(1, 1, 1, 3).setValues([['Email', 'Date Subscribed', 'Source']]);
        sheet.getRange(1, 1, 1, 3).setFontWeight('bold');
        sheet.setColumnWidth(1, 260);
        sheet.setColumnWidth(2, 160);
        sheet.setColumnWidth(3, 120);
      }

      // Check for duplicate
      const existing = sheet.getDataRange().getValues();
      for (let i = 1; i < existing.length; i++) {
        if (existing[i][0].toString().toLowerCase() === email) {
          return response({ success: true, duplicate: true });
        }
      }

      // Append new subscriber
      sheet.appendRow([
        email,
        new Date().toLocaleString('en-AU', { timeZone: 'Australia/Brisbane' }),
        'Website Popup'
      ]);

      return response({ success: true, duplicate: false });
    }

    return response({ success: false, error: 'Unknown action' });

  } catch(err) {
    return response({ success: false, error: err.toString() });
  }
}

function doGet(e) {
  // Return subscriber count for basic stats
  try {
    const sheet = SpreadsheetApp.openById(MAILING_SHEET_ID).getSheetByName('Subscribers');
    const count = sheet ? Math.max(0, sheet.getLastRow() - 1) : 0;
    return response({ success: true, count });
  } catch(err) {
    return response({ success: false, error: err.toString() });
  }
}

function response(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
